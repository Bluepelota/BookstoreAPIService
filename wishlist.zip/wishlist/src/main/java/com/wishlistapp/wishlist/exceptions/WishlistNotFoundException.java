package com.wishlistapp.wishlist.exceptions;

public class WishlistNotFoundException extends RuntimeException{
        public WishlistNotFoundException(String message) { super(message);}
}
